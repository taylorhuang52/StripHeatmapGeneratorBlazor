using System.Globalization;
using SkiaSharp;
using StripHeatmapGeneratorBlazor.Models;

namespace StripHeatmapGeneratorBlazor.Services;

public class StripRendererService
{
    /// <summary>
    /// 渲染 Strip Heatmap，回傳 base64 PNG 字串（可直接放進 img src）
    /// </summary>
    public string Render(
        Dictionary<int, List<DieRecord>> strips,
        string paramName,
        string fileBase,
        double? loLimit,
        double? hiLimit,
        int cellW    = HeatmapConfig.DefaultCellW,
        int cellH    = HeatmapConfig.DefaultCellH,
        int fontSize = HeatmapConfig.DefaultFontSz)
    {
        int maxX = strips.Count > 0
            ? strips.Values.SelectMany(l => l).Max(d => d.X) : 13;
        int maxY = strips.Count > 0
            ? strips.Values.SelectMany(l => l).Max(d => d.Y) : 13;

        int stripW = maxX * cellW;
        int stripH = maxY * cellH;
        int rows   = HeatmapConfig.GridRows;
        int cols   = HeatmapConfig.GridCols;

        int totalW = HeatmapConfig.Margin * 2
                   + cols * stripW
                   + (cols - 1) * HeatmapConfig.StripPadX;
        int totalH = HeatmapConfig.Margin * 2
                   + HeatmapConfig.TitleH
                   + rows * (HeatmapConfig.StripLabelH + stripH)
                   + (rows - 1) * HeatmapConfig.StripPadY;

        using var bmp    = new SKBitmap(totalW, totalH);
        using var canvas = new SKCanvas(bmp);
        canvas.Clear(SKColors.White);

        // ── Title ──────────────────────────────────────────────────────────
        string limitStr = (loLimit.HasValue || hiLimit.HasValue)
            ? $"  [{loLimit?.ToString("G4", CultureInfo.InvariantCulture) ?? "-∞"}" +
              $" ~ {hiLimit?.ToString("G4", CultureInfo.InvariantCulture) ?? "+∞"}]"
            : "";
        string title = $"{fileBase} {paramName} Strip Heatmap{limitStr}";

        using var titlePaint = new SKPaint
        {
            Color       = HeatmapConfig.ColorTitleFg,
            TextSize    = 18,
            IsAntialias = true,
            FakeBoldText = true,
            Typeface    = SKTypeface.FromFamilyName("Arial"),
        };
        float titleW = titlePaint.MeasureText(title);
        canvas.DrawText(title, (totalW - titleW) / 2f,
            HeatmapConfig.Margin + 20, titlePaint);

        // ── Shared paints ──────────────────────────────────────────────────
        using var valPaint = new SKPaint
        {
            Color       = SKColors.Black,
            TextSize    = fontSize,
            IsAntialias = false,
            Typeface    = SKTypeface.FromFamilyName("Arial"),
        };
        using var oosPaint = new SKPaint
        {
            Color       = HeatmapConfig.ColorOosLabel,
            TextSize    = fontSize,
            IsAntialias = false,
            Typeface    = SKTypeface.FromFamilyName("Arial"),
        };
        using var lblPaint = new SKPaint
        {
            Color        = SKColors.Black,
            TextSize     = 11,
            IsAntialias  = true,
            FakeBoldText = true,
            Typeface     = SKTypeface.FromFamilyName("Arial"),
        };
        using var cellPaint = new SKPaint { IsAntialias = false };

        // ── Draw each strip slot ───────────────────────────────────────────
        for (int col = 0; col < cols; col++)
        {
            for (int row = 0; row < rows; row++)
            {
                int sid = HeatmapConfig.StripGrid[col][row];
                int ox  = HeatmapConfig.Margin + col * (stripW + HeatmapConfig.StripPadX);
                int oy  = HeatmapConfig.Margin + HeatmapConfig.TitleH
                        + row * (HeatmapConfig.StripLabelH + stripH + HeatmapConfig.StripPadY);

                // "#N" label
                canvas.DrawText($"#{sid}", ox, oy + 12, lblPaint);
                oy += HeatmapConfig.StripLabelH;

                // No data → leave blank
                if (!strips.ContainsKey(sid)) continue;

                var lookup = strips[sid].ToDictionary(d => (d.X, d.Y));

                for (int dy = maxY; dy >= 1; dy--)
                {
                    for (int dx = 1; dx <= maxX; dx++)
                    {
                        float px = ox + (dx - 1) * cellW;
                        float py = oy + (maxY - dy) * cellH;
                        var rect = new SKRect(px, py, px + cellW - 1, py + cellH - 1);

                        if (!lookup.TryGetValue((dx, dy), out var die))
                        {
                            cellPaint.Color = HeatmapConfig.ColorMissing;
                            canvas.DrawRect(rect, cellPaint);
                            continue;
                        }

                        bool oos = die.HasValue
                            && ((loLimit.HasValue && die.Value < loLimit.Value)
                             || (hiLimit.HasValue && die.Value > hiLimit.Value));

                        SKColor bg = oos
                            ? HeatmapConfig.ColorOutOfSpec
                            : HeatmapConfig.BinColors.TryGetValue(die.Bin, out var bc)
                                ? bc
                                : HeatmapConfig.ColorDefault;

                        cellPaint.Color = bg;
                        canvas.DrawRect(rect, cellPaint);

                        if (die.HasValue)
                        {
                            string val   = die.Value.ToString("G4", CultureInfo.InvariantCulture);
                            var    paint = oos ? oosPaint : valPaint;
                            float  tw    = paint.MeasureText(val);
                            float  tx    = px + (cellW - tw) / 2f;
                            float  ty    = py + cellH / 2f + fontSize * 0.35f;
                            canvas.DrawText(val, tx, ty, paint);
                        }
                    }
                }
            }
        }

        // ── Encode PNG → base64 ────────────────────────────────────────────
        using var image  = SKImage.FromBitmap(bmp);
        using var data   = image.Encode(SKEncodedImageFormat.Png, 100);
        return Convert.ToBase64String(data.ToArray());
    }
}

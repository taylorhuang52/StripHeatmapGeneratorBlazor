using SkiaSharp;

namespace StripHeatmapGeneratorBlazor.Services;

/// <summary>全域共用常數：規格限制、Bin 顏色、良率測項</summary>
public static class HeatmapConfig
{
    // ── 固定 Grid 佈局 ──────────────────────────────────────────────────────
    public const int GridCols      = 4;
    public const int GridRows      = 6;
    public const int TotalStrips   = GridCols * GridRows; // 24
    public const int StripDieTotal = 169;                 // 每 strip 固定分母

    // grid[col][row] = strip ID（1-based）
    // Col 0 top→bottom: #6,#5,#4,#3,#2,#1
    // Col 1           : #12,#11,#10,#9,#8,#7
    // Col 2           : #18,#17,#16,#15,#14,#13
    // Col 3           : #24,#23,#22,#21,#20,#19
    public static readonly int[][] StripGrid = BuildGrid();

    private static int[][] BuildGrid()
    {
        var g = new int[GridCols][];
        for (int c = 0; c < GridCols; c++)
        {
            g[c] = new int[GridRows];
            for (int r = 0; r < GridRows; r++)
            {
                int baseId = c * GridRows + 1;
                g[c][r] = baseId + (GridRows - 1 - r);
            }
        }
        return g;
    }

    // ── 規格限制 ────────────────────────────────────────────────────────────
    public static readonly Dictionary<string, (double Lo, double Hi)> ParamLimits
        = new(StringComparer.OrdinalIgnoreCase)
    {
        { "VTH",     (1.5,   6.0)  },
        { "VFSD",    (0.4,   0.9)  },
        { "BVDSS_2", (19.65, 23.0) },
        { "BVDSS_1", (19.65, 22.5) },
        { "Delta3",  (0.02,  2.0)  },
        { "IPD_10V", (20.0,  40.0) },
        { "IDSS1",   (0.0,   10.0) },
        { "IDSS2",   (0.0,   10.0) },
        { "IDSS3",   (0.0,   10.0) },
    };

    // ── 良率計算測項 ─────────────────────────────────────────────────────────
    public static readonly HashSet<string> YieldParams
        = new(ParamLimits.Keys, StringComparer.OrdinalIgnoreCase);

    // ── Bin 顏色 ─────────────────────────────────────────────────────────────
    public static readonly Dictionary<int, SKColor> BinColors = new()
    {
        { 1, new SKColor(  0, 200,   0) },   // Pass    → 綠
        { 2, new SKColor( 50, 180,  50) },   // Pass2   → 深綠
        { 3, new SKColor(200, 200,   0) },   // Warn    → 黃
        { 4, new SKColor(255, 128,   0) },   // Warn2   → 橙
        { 5, new SKColor(255,   0,   0) },   // Fail    → 紅
        { 6, new SKColor(180,   0, 180) },   // Fail2   → 紫
    };

    public static readonly Dictionary<int, string> BinLabels = new()
    {
        { 1, "Pass" }, { 2, "Pass2" }, { 3, "Warn" },
        { 4, "Warn2"}, { 5, "Fail" }, { 6, "Fail2" },
    };

    public static readonly SKColor ColorOutOfSpec = new(210, 210, 210);
    public static readonly SKColor ColorMissing   = SKColors.White;
    public static readonly SKColor ColorTitleFg   = new(  0,  80, 200);
    public static readonly SKColor ColorOosLabel  = new(160,   0,   0);
    public static readonly SKColor ColorDefault   = new(160, 160, 160);

    // ── Render 預設尺寸 ──────────────────────────────────────────────────────
    public const int DefaultCellW   = 28;
    public const int DefaultCellH   = 18;
    public const int DefaultFontSz  = 8;
    public const int TitleH         = 40;
    public const int StripLabelH    = 18;
    public const int StripPadX      = 10;
    public const int StripPadY      = 14;
    public const int Margin         = 20;
}

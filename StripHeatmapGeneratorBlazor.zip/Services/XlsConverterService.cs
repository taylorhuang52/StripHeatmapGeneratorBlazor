using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace StripHeatmapGeneratorBlazor.Services;

public class XlsConverterService
{
    // Spec limits (updated after reading XLS header rows)
    private double _limVthLo=1.5,  _limVthHi=6.0;
    private double _limVfsdLo=0.4, _limVfsdHi=0.9;
    private double _limBv2Lo=19.65,_limBv2Hi=23.0;
    private double _limBv1Lo=19.65,_limBv1Hi=22.5;
    private double _limBvBin2Lo=20.9,_limBvBin2Hi=22.5;
    private double _limDeltaLo=0.02,_limDeltaHi=2.0;
    private double _limIpdLo=20.0, _limIpdHi=40.0;
    private double _limIdss=10.0;

    public record ConvertResult(string Csv, string Log, int Converted, int Skipped);

    public Task<ConvertResult> ConvertAsync(byte[] xlsBytes)
        => Task.Run(() => Convert(xlsBytes));

    private ConvertResult Convert(byte[] raw)
    {
        var log = new StringBuilder();
        void Log(string msg) => log.AppendLine(msg);

        Log("步驟 1/3：解析 OLE Compound Document…");
        byte[]? wbStream = ExtractWorkbookStream(raw);
        if (wbStream is null)
            return new ConvertResult("", "無法解析 OLE Compound Document", 0, 0);

        Log($"  ✓ Workbook stream：{wbStream.Length:N0} bytes");
        Log("步驟 2/3：解析 LoggerData 分頁…");

        var sst = new List<string>();
        long ldOffset = FindLoggerDataOffset(wbStream, sst);
        if (ldOffset < 0)
            return new ConvertResult("", "找不到 LoggerData 分頁", 0, 0);

        var allRows = ParseSheetRows(wbStream, ldOffset, sst);

        // Read spec limits from rows 3-4
        var minRow = allRows.GetValueOrDefault(3) ?? new();
        var maxRow = allRows.GetValueOrDefault(4) ?? new();
        _limVthLo    = GetD(minRow,  4, 1.5);   _limVthHi    = GetD(maxRow,  4, 6.0);
        _limVfsdLo   = GetD(minRow,  7, 0.4);   _limVfsdHi   = GetD(maxRow,  7, 0.9);
        _limBv2Lo    = GetD(minRow,  8, 19.65); _limBv2Hi    = GetD(maxRow,  8, 23.0);
        _limBv1Lo    = GetD(minRow,  9, 19.65); _limBv1Hi    = GetD(maxRow,  9, 22.5);
        _limBvBin2Lo = GetD(minRow, 10, 20.9);  _limBvBin2Hi = GetD(maxRow, 10, 22.5);
        _limDeltaLo  = GetD(minRow, 11, 0.02);  _limDeltaHi  = GetD(maxRow, 11, 2.0);
        _limIpdLo    = GetD(minRow, 12, 20.0);  _limIpdHi    = GetD(maxRow, 12, 40.0);
        _limIdss     = GetD(maxRow, 13, 10.0);

        Log($"  規格：VTH[{_limVthLo}~{_limVthHi}]  VFSD[{_limVfsdLo}~{_limVfsdHi}]" +
            $"  BVDSS1[{_limBv1Lo}~{_limBv1Hi}]  IPD[{_limIpdLo}~{_limIpdHi}]");

        Log("步驟 3/3：產生 CSV…");
        var sb = new StringBuilder();
        sb.AppendLine("Serial,Bin,X,Y,X_old,Y_old,VTH,GET VTH <1.5V,GET VTH >6V," +
                      "VFSD,BVDSS_2,BVDSS_1,BVDSS bin2,Delta3,IPD_10V,IDSS1,IDSS2,IDSS3,Wafer_ID");

        int converted = 0, skipped = 0, globalSerial = 0;

        foreach (var rowIdx in allRows.Keys.OrderBy(k => k))
        {
            if (rowIdx < 10) continue;
            var row = allRows[rowIdx];

            string remark = GetS(row, 16);
            if (string.IsNullOrWhiteSpace(remark)) { skipped++; continue; }

            string waferStr = remark.Trim();
            if (waferStr.Length >= 2) waferStr = waferStr[^2..];
            if (!int.TryParse(waferStr, out int waferId)) { skipped++; continue; }

            globalSerial++;
            int xOld = row.TryGetValue(2, out var xo) && xo is double xd ? (int)xd : 0;
            if (xOld <= 0) { skipped++; continue; }

            int x = (xOld + 12) / 13;
            int y = 13 - ((xOld - 1) % 13);

            int serial = row.TryGetValue(0, out var so) && so is double sd ? (int)sd : globalSerial;

            string vth    = FmtD(row, 4),  gtvLo = FmtD(row, 5), gtvHi = FmtD(row, 6);
            string vfsd   = FmtD(row, 7),  bv2   = FmtD(row, 8), bv1   = FmtD(row, 9);
            string bvBin2 = FmtD(row, 10), delta = FmtD(row, 11),ipd   = FmtD(row, 12);
            string idss1  = FmtD(row, 13), idss2 = FmtD(row, 14),idss3 = FmtD(row, 15);

            int bin = row.TryGetValue(1, out var bo) && bo is double bd
                ? (int)bd
                : CalcBin(vth, vfsd, bv2, bv1, bvBin2, delta, ipd, idss1, idss2, idss3);

            sb.AppendLine($"{serial},{bin},{x},{y},{xOld},0," +
                          $"{vth},{gtvLo},{gtvHi}," +
                          $"{vfsd},{bv2},{bv1},{bvBin2},{delta},{ipd},{idss1},{idss2},{idss3}," +
                          $"{waferId}");
            converted++;
        }

        Log($"✅ 完成！共 {converted} 筆，略過 {skipped} 筆");
        return new ConvertResult(sb.ToString(), log.ToString(), converted, skipped);
    }

    // ══════════════════════════════════════
    //  OLE / BIFF8
    // ══════════════════════════════════════
    private static byte[]? ExtractWorkbookStream(byte[] raw)
    {
        if (raw.Length < 512) return null;
        int secSize = 1 << BitConverter.ToInt16(raw, 30);

        var fatSectors = new List<int>();
        for (int i = 0; i < 109; i++)
        {
            int sec = BitConverter.ToInt32(raw, 76 + i * 4);
            if (sec < 0) break;
            fatSectors.Add(sec);
        }
        var fat = new int[fatSectors.Count * secSize / 4];
        for (int fi = 0; fi < fatSectors.Count; fi++)
        {
            int off = 512 + fatSectors[fi] * secSize;
            for (int j = 0; j < secSize / 4; j++)
                fat[fi * secSize / 4 + j] = BitConverter.ToInt32(raw, off + j * 4);
        }

        int dirSec = BitConverter.ToInt32(raw, 48);
        int dirOff = 512 + dirSec * secSize;
        int wbStart = -1;

        for (int e = 0; e < 32; e++)
        {
            int entOff  = dirOff + e * 128;
            if (entOff + 128 > raw.Length) break;
            int nameLen = BitConverter.ToInt16(raw, entOff + 64);
            int entType = raw[entOff + 66];
            if (entType == 0) continue;
            int startSec = BitConverter.ToInt32(raw, entOff + 116);
            string name = nameLen > 0 && nameLen <= 64
                ? Encoding.Unicode.GetString(raw, entOff, nameLen).TrimEnd('\0')
                : "";
            if (name.Equals("Workbook", StringComparison.OrdinalIgnoreCase) ||
                name.Equals("Book",     StringComparison.OrdinalIgnoreCase))
            { wbStart = startSec; break; }
        }
        if (wbStart < 0) return null;

        var ms = new MemoryStream();
        int cur = wbStart;
        var visited = new HashSet<int>();
        while (cur >= 0 && cur < 0x7FFFFFF0)
        {
            if (!visited.Add(cur)) break;
            int off = 512 + cur * secSize;
            if (off + secSize > raw.Length) break;
            ms.Write(raw, off, secSize);
            if (cur >= fat.Length) break;
            cur = fat[cur];
        }
        return ms.ToArray();
    }

    private static long FindLoggerDataOffset(byte[] wb, List<string> sst)
    {
        var sheets = new List<(string name, int offset)>();
        int pos = 0;
        while (pos < wb.Length - 4)
        {
            int rt = BitConverter.ToInt16(wb, pos);
            int rl = BitConverter.ToUInt16(wb, pos + 2);

            if (rt == 0x00FC && rl >= 8)
            {
                int unique = BitConverter.ToInt32(wb, pos + 4 + 4);
                int sp = pos + 4 + 8;
                int boundary = pos + 4 + rl;
                while (sst.Count < unique && sp < boundary)
                {
                    int cc  = BitConverter.ToUInt16(wb, sp);
                    byte fl = wb[sp + 2]; sp += 3;
                    int rich = 0;
                    if ((fl & 0x08) != 0) { rich = BitConverter.ToUInt16(wb, sp); sp += 2; }
                    if ((fl & 0x04) != 0) { int ph = BitConverter.ToInt32(wb, sp); sp += 4 + ph; }
                    if ((fl & 0x01) == 0)
                    {
                        var bytes = new byte[cc];
                        Buffer.BlockCopy(wb, sp, bytes, 0, Math.Min(cc, wb.Length - sp));
                        sp += cc;
                        sst.Add(Encoding.Latin1.GetString(bytes));
                    }
                    else
                    {
                        var bytes = new byte[cc * 2];
                        Buffer.BlockCopy(wb, sp, bytes, 0, Math.Min(cc * 2, wb.Length - sp));
                        sp += cc * 2;
                        sst.Add(Encoding.Unicode.GetString(bytes));
                    }
                    sp += rich * 4;
                }
            }
            if (rt == 0x0085 && rl >= 7)
            {
                int shOff   = BitConverter.ToInt32(wb, pos + 4);
                int nameLen = wb[pos + 4 + 6];
                byte enc    = wb[pos + 4 + 7];
                string sname = enc == 0
                    ? Encoding.Latin1.GetString(wb, pos+4+8, Math.Min(nameLen, wb.Length-pos-12))
                    : Encoding.Unicode.GetString(wb, pos+4+8, Math.Min(nameLen*2, wb.Length-pos-12));
                sheets.Add((sname.TrimEnd('\0'), shOff));
            }
            pos += 4 + rl;
        }

        foreach (var sh in sheets)
            if (sh.name.Equals("LoggerData", StringComparison.OrdinalIgnoreCase))
                return sh.offset;
        return sheets.Count > 0 ? sheets[^1].offset : -1;
    }

    private static Dictionary<int, Dictionary<int, object>> ParseSheetRows(
        byte[] wb, long startOffset, List<string> sst)
    {
        var rows = new Dictionary<int, Dictionary<int, object>>();
        void Set(int r, int c, object v)
        {
            if (!rows.ContainsKey(r)) rows[r] = new();
            rows[r][c] = v;
        }

        int pos = (int)startOffset;
        bool started = false;
        while (pos < wb.Length - 4)
        {
            int rt = BitConverter.ToUInt16(wb, pos);
            int rl = BitConverter.ToUInt16(wb, pos + 2);

            if (rt == 0x0809) { if (started) break; started = true; }
            if (started)
            {
                if (rt == 0x0203 && rl >= 14)
                { Set(BitConverter.ToUInt16(wb,pos+4), BitConverter.ToUInt16(wb,pos+6), BitConverter.ToDouble(wb,pos+10)); }
                else if (rt == 0x00FD && rl >= 10)
                { int si = BitConverter.ToInt32(wb,pos+10); Set(BitConverter.ToUInt16(wb,pos+4), BitConverter.ToUInt16(wb,pos+6), si < sst.Count ? (object)sst[si] : ""); }
                else if (rt == 0x027E && rl >= 10)
                { Set(BitConverter.ToUInt16(wb,pos+4), BitConverter.ToUInt16(wb,pos+6), DecodeRK(BitConverter.ToInt32(wb,pos+10))); }
                else if (rt == 0x00BD && rl >= 6)
                {
                    int r = BitConverter.ToUInt16(wb,pos+4), cFirst = BitConverter.ToUInt16(wb,pos+6);
                    int n = (rl - 6) / 6;
                    for (int i = 0; i < n; i++)
                    {
                        int rkOff = pos + 4 + 4 + i * 6 + 2;
                        if (rkOff + 4 <= pos + 4 + rl)
                            Set(r, cFirst + i, DecodeRK(BitConverter.ToInt32(wb, rkOff)));
                    }
                }
                else if (rt == 0x000A) break;
            }
            pos += 4 + rl;
        }
        return rows;
    }

    private static double DecodeRK(int rkv)
    {
        double v = (rkv & 0x02) != 0
            ? rkv >> 2
            : BitConverter.Int64BitsToDouble(((long)(rkv & 0xFFFFFFFC)) << 32);
        if ((rkv & 0x01) != 0) v /= 100.0;
        return v;
    }

    // ── Helpers ────────────────────────────────────────────────────────────
    private static double GetD(Dictionary<int,object> row, int col, double def)
    {
        if (!row.TryGetValue(col, out var v)) return def;
        if (v is double d) return d;
        string s = Regex.Replace(v.ToString()!.Trim(), @"[^\d.\-+eE].*$", "");
        return double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out double p) ? p : def;
    }

    private static string GetS(Dictionary<int,object> row, int col)
        => row.TryGetValue(col, out var v) ? v?.ToString() ?? "" : "";

    private static string FmtD(Dictionary<int,object> row, int col)
        => row.TryGetValue(col, out var v) && v is double d
            ? d.ToString("G6", CultureInfo.InvariantCulture) : "";

    private int CalcBin(string vth, string vfsd, string bv2, string bv1,
        string bvBin2, string delta, string ipd, string i1, string i2, string i3)
    {
        if (!TryP(vth,   out double dVth))   return 6;
        if (!TryP(vfsd,  out double dVfsd))  return 6;
        if (!TryP(bv2,   out double dBv2))   return 6;
        if (!TryP(bv1,   out double dBv1))   return 6;
        if (!TryP(bvBin2,out double dBvB))   return 6;
        if (!TryP(delta, out double dDelta)) return 6;
        if (!TryP(ipd,   out double dIpd))   return 6;
        if (!TryP(i1,    out double dI1))    return 6;
        if (!TryP(i2,    out double dI2))    return 6;
        if (!TryP(i3,    out double dI3))    return 6;

        if (dIpd  < _limIpdLo  || dIpd  > _limIpdHi)  return 5;
        if (dVfsd < _limVfsdLo || dVfsd > _limVfsdHi)  return 3;
        if (dVth  < _limVthLo  || dVth  > _limVthHi)   return 6;
        if (dBv2  < _limBv2Lo  || dBv2  > _limBv2Hi)   return 6;
        if (dBv1  < _limBv1Lo  || dBv1  > _limBv1Hi)   return 6;
        if (dDelta< _limDeltaLo|| dDelta> _limDeltaHi)  return 6;
        if (dI1 > _limIdss || dI2 > _limIdss || dI3 > _limIdss) return 6;
        return dBvB < _limBvBin2Lo ? 1 : 2;
    }

    private static bool TryP(string s, out double v)
    {
        v = 0;
        return !string.IsNullOrEmpty(s) &&
               double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out v);
    }
}

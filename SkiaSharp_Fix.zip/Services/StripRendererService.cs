using System.Globalization;
using System.Text;
using System.Text.Json;
using StripHeatmapGeneratorBlazor.Models;

namespace StripHeatmapGeneratorBlazor.Services;

/// <summary>
/// 不依賴 SkiaSharp。
/// 將繪圖指令序列化成 JSON，交由 wwwroot/heatmap-renderer.js 的
/// Canvas 2D API 完成繪製並回傳 base64 PNG。
/// </summary>
public class StripRendererService
{
    /// <summary>
    /// 回傳繪圖用的 RenderPayload JSON 字串。
    /// Home.razor 呼叫 JS interop renderHeatmap(payload) 後拿到 base64 PNG。
    /// </summary>
    public string BuildPayload(
        Dictionary<int, List<DieRecord>> strips,
        string paramName,
        string fileBase,
        double? loLimit,
        double? hiLimit,
        int cellW    = HeatmapConfig.DefaultCellW,
        int cellH    = HeatmapConfig.DefaultCellH,
        int fontSize = HeatmapConfig.DefaultFontSz)
    {
        int maxX = strips.Count > 0
            ? strips.Values.SelectMany(l => l).Max(d => d.X) : 13;
        int maxY = strips.Count > 0
            ? strips.Values.SelectMany(l => l).Max(d => d.Y) : 13;

        int stripW = maxX * cellW;
        int stripH = maxY * cellH;
        int rows   = HeatmapConfig.GridRows;
        int cols   = HeatmapConfig.GridCols;

        int totalW = HeatmapConfig.Margin * 2
                   + cols * stripW
                   + (cols - 1) * HeatmapConfig.StripPadX;
        int totalH = HeatmapConfig.Margin * 2
                   + HeatmapConfig.TitleH
                   + rows * (HeatmapConfig.StripLabelH + stripH)
                   + (rows - 1) * HeatmapConfig.StripPadY;

        string limitStr = (loLimit.HasValue || hiLimit.HasValue)
            ? $"  [{loLimit?.ToString("G4", CultureInfo.InvariantCulture) ?? "-∞"}" +
              $" ~ {hiLimit?.ToString("G4", CultureInfo.InvariantCulture) ?? "+∞"}]"
            : "";
        string title = $"{fileBase} {paramName} Strip Heatmap{limitStr}";

        // 建立所有 cell 繪圖指令
        var cells = new List<object>();

        for (int col = 0; col < cols; col++)
        {
            for (int row = 0; row < rows; row++)
            {
                int sid = HeatmapConfig.StripGrid[col][row];
                int ox  = HeatmapConfig.Margin + col * (stripW + HeatmapConfig.StripPadX);
                int oy  = HeatmapConfig.Margin + HeatmapConfig.TitleH
                        + row * (HeatmapConfig.StripLabelH + stripH + HeatmapConfig.StripPadY);

                // Strip label "#N"
                cells.Add(new { type = "label", text = $"#{sid}", x = ox, y = oy + 12 });
                oy += HeatmapConfig.StripLabelH;

                if (!strips.ContainsKey(sid)) continue;

                var lookup = strips[sid].ToDictionary(d => (d.X, d.Y));

                for (int dy = maxY; dy >= 1; dy--)
                {
                    for (int dx = 1; dx <= maxX; dx++)
                    {
                        int px = ox + (dx - 1) * cellW;
                        int py = oy + (maxY - dy) * cellH;

                        if (!lookup.TryGetValue((dx, dy), out var die))
                        {
                            cells.Add(new
                            {
                                type = "cell",
                                x = px, y = py, w = cellW - 1, h = cellH - 1,
                                bg   = HeatmapConfig.ColorMissing,
                                text = (string?)null,
                                fg   = "#000000"
                            });
                            continue;
                        }

                        bool oos = die.HasValue
                            && ((loLimit.HasValue && die.Value < loLimit.Value)
                             || (hiLimit.HasValue && die.Value > hiLimit.Value));

                        string bg = oos
                            ? HeatmapConfig.ColorOutOfSpec
                            : HeatmapConfig.BinColors.TryGetValue(die.Bin, out var bc)
                                ? bc
                                : HeatmapConfig.ColorDefault;

                        string? valText = die.HasValue
                            ? die.Value.ToString("G4", CultureInfo.InvariantCulture)
                            : null;

                        cells.Add(new
                        {
                            type = "cell",
                            x = px, y = py, w = cellW - 1, h = cellH - 1,
                            bg,
                            text = valText,
                            fg   = oos ? HeatmapConfig.ColorOosLabel : "#000000"
                        });
                    }
                }
            }
        }

        var payload = new
        {
            width    = totalW,
            height   = totalH,
            title,
            titleColor = HeatmapConfig.ColorTitleFg,
            fontSize,
            cells
        };

        return JsonSerializer.Serialize(payload);
    }
}

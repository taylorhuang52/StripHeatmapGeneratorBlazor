namespace StripHeatmapGeneratorBlazor.Services;

/// <summary>全域共用常數：規格限制、Bin 顏色、良率測項</summary>
public static class HeatmapConfig
{
    // ── 固定 Grid 佈局 ──────────────────────────────────────────────────────
    public const int GridCols      = 4;
    public const int GridRows      = 6;
    public const int TotalStrips   = GridCols * GridRows; // 24
    public const int StripDieTotal = 169;                 // 每 strip 固定分母

    // grid[col][row] = strip ID（1-based）
    public static readonly int[][] StripGrid = BuildGrid();

    private static int[][] BuildGrid()
    {
        var g = new int[GridCols][];
        for (int c = 0; c < GridCols; c++)
        {
            g[c] = new int[GridRows];
            for (int r = 0; r < GridRows; r++)
            {
                int baseId = c * GridRows + 1;
                g[c][r] = baseId + (GridRows - 1 - r);
            }
        }
        return g;
    }

    // ── 規格限制 ────────────────────────────────────────────────────────────
    public static readonly Dictionary<string, (double Lo, double Hi)> ParamLimits
        = new(StringComparer.OrdinalIgnoreCase)
    {
        { "VTH",     (1.5,   6.0)  },
        { "VFSD",    (0.4,   0.9)  },
        { "BVDSS_2", (19.65, 23.0) },
        { "BVDSS_1", (19.65, 22.5) },
        { "Delta3",  (0.02,  2.0)  },
        { "IPD_10V", (20.0,  40.0) },
        { "IDSS1",   (0.0,   10.0) },
        { "IDSS2",   (0.0,   10.0) },
        { "IDSS3",   (0.0,   10.0) },
    };

    // ── 良率計算測項 ─────────────────────────────────────────────────────────
    public static readonly HashSet<string> YieldParams
        = new(ParamLimits.Keys, StringComparer.OrdinalIgnoreCase);

    // ── Bin 顏色（CSS 字串，不依賴 SkiaSharp）────────────────────────────────
    public static readonly Dictionary<int, string> BinColors = new()
    {
        { 1, "#00c800" },   // Pass    → 綠
        { 2, "#32b432" },   // Pass2   → 深綠
        { 3, "#c8c800" },   // Warn    → 黃
        { 4, "#ff8000" },   // Warn2   → 橙
        { 5, "#ff0000" },   // Fail    → 紅
        { 6, "#b400b4" },   // Fail2   → 紫
    };

    public static readonly Dictionary<int, string> BinLabels = new()
    {
        { 1, "Pass" }, { 2, "Pass2" }, { 3, "Warn" },
        { 4, "Warn2"}, { 5, "Fail" }, { 6, "Fail2" },
    };

    public const string ColorOutOfSpec = "#d2d2d2";
    public const string ColorMissing   = "#ffffff";
    public const string ColorTitleFg   = "#0050c8";
    public const string ColorOosLabel  = "#a00000";
    public const string ColorDefault   = "#a0a0a0";

    // ── Render 預設尺寸 ──────────────────────────────────────────────────────
    public const int DefaultCellW   = 28;
    public const int DefaultCellH   = 18;
    public const int DefaultFontSz  = 8;
    public const int TitleH         = 40;
    public const int StripLabelH    = 18;
    public const int StripPadX      = 10;
    public const int StripPadY      = 14;
    public const int Margin         = 20;
}
